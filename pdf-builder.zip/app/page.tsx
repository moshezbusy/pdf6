"use client"

import { useState } from "react"
import {
  ImageIcon,
  Type,
  Square,
  CircleIcon,
  MousePointerClick,
  Heading1,
  Heading2,
  ListOrdered,
  Table,
  QrCode,
  FilePenLineIcon as Signature,
  BarChart4,
  FileImage,
  Paperclip,
  ChevronDown,
  Settings,
  Save,
  Download,
  Share2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function PDFBuilder() {
  const [selectedBlock, setSelectedBlock] = useState<string | null>("text")

  const blocks = [
    { id: "text", name: "Text", icon: Type },
    { id: "heading1", name: "Heading 1", icon: Heading1 },
    { id: "heading2", name: "Heading 2", icon: Heading2 },
    { id: "image", name: "Image", icon: ImageIcon },
    { id: "rectangle", name: "Rectangle", icon: Square },
    { id: "circle", name: "Circle", icon: CircleIcon },
    { id: "button", name: "Button", icon: MousePointerClick },
    { id: "list", name: "List", icon: ListOrdered },
    { id: "table", name: "Table", icon: Table },
    { id: "qrcode", name: "QR Code", icon: QrCode },
    { id: "signature", name: "Signature", icon: Signature },
    { id: "chart", name: "Chart", icon: BarChart4 },
    { id: "logo", name: "Logo", icon: FileImage },
    { id: "attachment", name: "Attachment", icon: Paperclip },
  ]

  return (
    <div className="flex h-screen w-full bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 h-14 border-b bg-background z-10 flex items-center px-4 justify-between">
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-semibold">PDF Builder</h1>
          <span className="text-xs bg-muted px-2 py-0.5 rounded-full">Draft</span>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
          <Button variant="outline" size="sm">
            <Save className="h-4 w-4 mr-2" />
            Save
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button size="sm">
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
        </div>
      </header>

      <div className="flex w-full h-full pt-14">
        {/* Left Sidebar - Block Selection */}
        <div className="w-64 border-r bg-background h-full flex flex-col">
          <div className="p-4 border-b">
            <h2 className="font-medium text-sm">Elements</h2>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-3 grid grid-cols-2 gap-2">
              {blocks.map((block) => (
                <Button
                  key={block.id}
                  variant={selectedBlock === block.id ? "secondary" : "outline"}
                  size="sm"
                  className="h-20 flex flex-col justify-center items-center gap-2 text-xs"
                  onClick={() => setSelectedBlock(block.id)}
                >
                  <block.icon className="h-6 w-6" />
                  {block.name}
                </Button>
              ))}
            </div>
          </ScrollArea>
          <div className="p-3 border-t">
            <Button className="w-full">Add Custom Element</Button>
          </div>
        </div>

        {/* Middle Section - Block Settings */}
        <div className="w-80 border-r bg-background h-full flex flex-col">
          <div className="p-4 border-b flex justify-between items-center">
            <h2 className="font-medium text-sm">Properties</h2>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm">
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Copy Properties</DropdownMenuItem>
                <DropdownMenuItem>Paste Properties</DropdownMenuItem>
                <DropdownMenuItem>Reset to Default</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-4">
              <Tabs defaultValue="style">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="style">Style</TabsTrigger>
                  <TabsTrigger value="layout">Layout</TabsTrigger>
                  <TabsTrigger value="advanced">Advanced</TabsTrigger>
                </TabsList>
                <TabsContent value="style" className="space-y-4 pt-4">
                  {selectedBlock === "text" && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="text-content">Text Content</Label>
                        <Input id="text-content" placeholder="Enter text..." defaultValue="Sample text content" />
                      </div>
                      <div className="space-y-2">
                        <Label>Font Family</Label>
                        <Select defaultValue="inter">
                          <SelectTrigger>
                            <SelectValue placeholder="Select font" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="inter">Inter</SelectItem>
                            <SelectItem value="roboto">Roboto</SelectItem>
                            <SelectItem value="poppins">Poppins</SelectItem>
                            <SelectItem value="opensans">Open Sans</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Font Size</Label>
                        <div className="flex items-center gap-2">
                          <Slider defaultValue={[16]} max={72} step={1} className="flex-1" />
                          <span className="text-sm w-8 text-center">16px</span>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Font Weight</Label>
                        <Select defaultValue="regular">
                          <SelectTrigger>
                            <SelectValue placeholder="Select weight" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="light">Light</SelectItem>
                            <SelectItem value="regular">Regular</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="semibold">Semibold</SelectItem>
                            <SelectItem value="bold">Bold</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Text Color</Label>
                        <div className="flex gap-2">
                          <div className="w-8 h-8 rounded-md border bg-black"></div>
                          <Input defaultValue="#000000" className="flex-1" />
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="text-bold">Bold</Label>
                        <Switch id="text-bold" />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="text-italic">Italic</Label>
                        <Switch id="text-italic" />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="text-underline">Underline</Label>
                        <Switch id="text-underline" />
                      </div>
                    </>
                  )}

                  {selectedBlock === "image" && (
                    <>
                      <div className="space-y-2">
                        <Label>Image Source</Label>
                        <div className="border-2 border-dashed rounded-md p-6 text-center">
                          <ImageIcon className="h-8 w-8 mx-auto text-muted-foreground" />
                          <p className="text-sm text-muted-foreground mt-2">
                            Drag and drop an image or click to browse
                          </p>
                          <Button variant="outline" size="sm" className="mt-2">
                            Upload Image
                          </Button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Border Radius</Label>
                        <div className="flex items-center gap-2">
                          <Slider defaultValue={[0]} max={50} step={1} className="flex-1" />
                          <span className="text-sm w-8 text-center">0px</span>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Opacity</Label>
                        <div className="flex items-center gap-2">
                          <Slider defaultValue={[100]} max={100} step={1} className="flex-1" />
                          <span className="text-sm w-8 text-center">100%</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="image-shadow">Drop Shadow</Label>
                        <Switch id="image-shadow" />
                      </div>
                    </>
                  )}
                </TabsContent>
                <TabsContent value="layout" className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label>Position</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <Label className="text-xs">X</Label>
                        <Input defaultValue="0" />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Y</Label>
                        <Input defaultValue="0" />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Size</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <Label className="text-xs">Width</Label>
                        <Input defaultValue="200" />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Height</Label>
                        <Input defaultValue="auto" />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Margin</Label>
                    <div className="grid grid-cols-4 gap-2">
                      <div className="space-y-1">
                        <Label className="text-xs">Top</Label>
                        <Input defaultValue="0" />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Right</Label>
                        <Input defaultValue="0" />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Bottom</Label>
                        <Input defaultValue="0" />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Left</Label>
                        <Input defaultValue="0" />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Padding</Label>
                    <div className="grid grid-cols-4 gap-2">
                      <div className="space-y-1">
                        <Label className="text-xs">Top</Label>
                        <Input defaultValue="0" />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Right</Label>
                        <Input defaultValue="0" />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Bottom</Label>
                        <Input defaultValue="0" />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Left</Label>
                        <Input defaultValue="0" />
                      </div>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="advanced" className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label>Z-Index</Label>
                    <Input defaultValue="0" />
                  </div>
                  <div className="space-y-2">
                    <Label>Rotation</Label>
                    <div className="flex items-center gap-2">
                      <Slider defaultValue={[0]} max={360} step={1} className="flex-1" />
                      <span className="text-sm w-8 text-center">0°</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="element-visible">Visible</Label>
                    <Switch id="element-visible" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="element-lock">Lock Position</Label>
                    <Switch id="element-lock" />
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </ScrollArea>
        </div>

        {/* Right Section - PDF Preview Canvas */}
        <div className="flex-1 bg-muted h-full flex flex-col">
          <div className="p-4 border-b bg-background flex justify-between items-center">
            <h2 className="font-medium text-sm">Preview</h2>
            <div className="flex items-center gap-2">
              <Select defaultValue="100">
                <SelectTrigger className="w-24">
                  <SelectValue placeholder="Zoom" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="50">50%</SelectItem>
                  <SelectItem value="75">75%</SelectItem>
                  <SelectItem value="100">100%</SelectItem>
                  <SelectItem value="125">125%</SelectItem>
                  <SelectItem value="150">150%</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <MousePointerClick className="h-4 w-4 mr-2" />
                Select
              </Button>
            </div>
          </div>
          <div className="flex-1 p-8 overflow-auto flex justify-center items-start">
            <div className="bg-white shadow-lg w-[595px] h-[842px] relative">
              {/* A4 size in pixels at 72dpi */}
              {selectedBlock === "text" && (
                <div className="absolute border-2 border-blue-500 p-4 left-20 top-40 w-64 h-16 flex items-center justify-center bg-white">
                  <p>Sample text content</p>
                </div>
              )}
              {selectedBlock === "image" && (
                <div className="absolute border-2 border-blue-500 left-20 top-80 w-64 h-48 flex items-center justify-center bg-gray-100">
                  <ImageIcon className="h-12 w-12 text-gray-400" />
                </div>
              )}
              {/* Grid lines for visual reference */}
              <div className="absolute inset-0 grid grid-cols-12 grid-rows-12 pointer-events-none">
                {Array.from({ length: 12 }).map((_, i) => (
                  <div key={`col-${i}`} className="border-r border-gray-100 h-full" />
                ))}
                {Array.from({ length: 12 }).map((_, i) => (
                  <div key={`row-${i}`} className="border-b border-gray-100 w-full" />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
